# Chapter 21 - Calgary

### I. The Calgary Airport

**7:42 AM** - Calgary International Airport

![iceart._Arrival_hall_of_Russian_airport._People_stand_and_greet_5b464e3a-f4cc-4b84-a4fa-4c9ebfa1c352.png](Chapter%2021%20-%20Calgary/iceart._Arrival_hall_of_Russian_airport._People_stand_and_greet_5b464e3a-f4cc-4b84-a4fa-4c9ebfa1c352.png)

The arrivals gate was a chaotic mess of movement and noise ; suitcases slamming, babies crying, wheels squeaking, impatient folks rushing around.

But then the crowd parted just enough.

And there they were.

Haoyu’s kids saw him first.

Haoyu’s son clutched a stuffed dinosaur like a talisman of safety. His daughter yawned wide enough to pop her jaw. Haoyu’s wife looked somewhere between relieved and *pissed*.

> “Baba!” she cried, leaping straight into his chest.
> 

Haoyu dropped to one knee, arms wide, and caught them both as they collided into him like a tidal wave of small limbs and sobs and overdue affection. His son didn’t say anything ; he just squeezed tighter, dinosaur pressed between them like an old friend reunited too.

> “We missed you so much,” his daughter mumbled into his shoulder.
> 

> “I missed you too,” Haoyu whispered, pressing his face into their hair, eyes stinging.
> 

Then came his wife.

She didn’t say anything at first either.

Just walked toward him slowly with a look that blended **relief**, **exhaustion**, and **repressed fury**. But when she reached him, she pulled him into a long, **tight hug** ; one hand gripping the back of his neck, the other resting gently over his heart.

> “I should slap you,” she muttered in Mandarin.
> 

> “I’d probably deserve it,” he replied.
> 

But her hand didn’t move. She just held him a second longer.

Dallas leaned against a post near the terminal doors, sipping expensive terrible airport coffee like it was cheap whiskey. He watched the ragtag team emerge behind Haoyu’s family: Dmitry Alexeyev, bleary-eyed and already swearing at his tablet in Russian, offered a curt nod and a handshake that turned into a shoulder-grab, a relic of an old-world comrade’s greeting. He’d worked two decades on the Echofall project, spending winters in Chicago, Huntsville, D.C., and even Montana.

**Yuyan Chan** stepped forward next, all calm smiles and tidy mannerisms ; sleeves neatly rolled, hair combed even after the flight.

Haoyu turned to face him.

They clasped hands and gave each other the **double-nod of respect** ; the traditional greeting from **Mainland China**, practiced even after years abroad.

> “Laoshi,” Jonny said softly, referring to Haoyu as “teacher” ; a term of endearment and esteem from their university days.
> 

> “Xiansheng,” Haoyu replied, nodding once more. “It’s good to see you again.”
> 

And then came Steven Young, loping up with his signature lopsided grin.

Steven was a big man, great beard, wore a cowboy hat far too pristine for someone who claimed it wasn’t his first rodeo, a jean jacket over a NASA tank top, cargo shorts, and flip-flops. Slung over his shoulder was a custom bio-spectrum scanner that looked like it’d been duct-taped together during a hurricane.

He gave Dallas a nod.

> “Nice to finally meet you, Mr. Red Ranch. I’m Steven. From Florida born and bred.”
> 
> 
> “Soon as we crack that alien guitar, I’m takin’ you swamp chicken huntin’ down in the Everglades.”
> 

Dallas blinked.

> “Swamp... chicken?”
> 

> “Oh yeah,” Steven said with a grin, pushing his cowboy hat back. “That what we call them gators, taste just like a giant chicken from a swamp.”
> 

Dallas raised a skeptical brow, looking at his shorts and flip flops.

> “You know it ain’t Florida weather up here, right?”
> 

Steven squinted out the glass of the airport windows seeing glimpses of the low, grey prairie sky.

> “How bad can it be? Never been to Canada, let alone the prairies, but it’s just flatlands like Texas, right?”
> 

Dallas muttered something under his breath about frostbite and hubris…

After a few more exchanges the final crew member arrived;

Dr. Pragnya Reddy came striding through the gate like she was late for a launch sequence, hair tied in a messy bun, half-buttoned lab coat thrown over travel sweats, and a duffel bag that looked like it had been repurposed from an old satellite payload.

She didn’t bother with small talk ; just clapped Haoyu on the shoulder and muttered:

> “I’ve never seen an alien map before… so I can’t promise to be useful, but, I’ll do my best”
> 

---

They began shuffling towards the parking garage, wheeling bags and slinging backpacks like a ragtag expedition team trying to catch a train to another planet.

Dallas glanced over at Yuyan Chan, who was eyeing the F1 truck with a mix of curiosity and alarm.

> “I can tell by the way you’re dressed,” Dallas said, tipping his hat, “you ain’t never sat in a 500-year-old pickup before.”
> 
> 
> “So congratulations ; you’re ridin’ shotgun with me.”
> 

Yuyan blinked behind his glasses, cracked a small grin, and shrugged.

> “Guess I’m overdue for some culture shock.”
> 

Dallas smirked and clapped him on the back before heading for the truck.

---

Meanwhile, at the rental car, the trunk packed to the brim with luggage - probably broke a couple things trying to force the lid shut. Haoyu's wife and kids settled into the backseat first. His daughter curled up with her stuffed toy in her lap, sitting on the wifes left knee. His son mashed buttons on a dead tablet, already bored, sitting uncomfortably and finicking on the wifes right knee. His wife sighed, gave Haoyu one last *"you better know what you're doing"* look, then in climbed Dmitry and Dr. Pragnya Reddy - all stuffed into the backseat uncomfortably like tight packed sardines in a can

Dmitry muttered something about elbow room and began scanning for satellite interference with a repurposed comms sniffer. Pragnya was already halfway into her laptop, mumbling about thermal degradation patterns in alien alloys.

The last to climb in was **Steven Young**, who ; as the **largest of the bunch** ; was assigned the **passenger seat**, otherwise there’s no way everyone would’ve fit in the back.

As soon as the door shut and Haoyu turned the ignition, Steven was already talking.

> “Man, I flew in from Florida this morning, and lemme tell you ; I’ve been in swamps, hurricanes, and once inside a hollowed-out gator with three busted ribs. But this Canadian cold?”
> 
> 
> He pulled his jean jacket tighter over his chest and gestured vaguely out the windshield.
> 
> “This *ain’t right*. My puppies (toes) are mad at me.”
> 

Haoyu snorted softly.

> “Should’ve worn boots.”
> 

> “I got flip-flops with good grip,” Steven shot back proudly. “Hell, I’ll take you out with real swamp cowboys to wrangle some boar sometime, Commander. Teach ya how to tickle a catfish in a sinkhole with one hand and make moonshine with the other.”
> 

> “Sounds a lot better than spending the remainder of my days in prison.” replied Haoyu
> 

The car rolled forward, pulling out of the garage behind the Ford.

Haoyu glanced in the mirror ; at his wife and kids, his friends, and the stacks of old gear beside them. Then he looked over at Steven, who was now adjusting the heat vents with a suspicious look.

> “Alright,” Haoyu said, tightening his grip on the wheel.
> 
> 
> “Let’s talk next steps. We’ve got a starmap no one understands. We’ve got four brilliant minds, a barn full of power tools… we can buy whatever lab equipment we need, a guitar etched with a map of the galaxy, and a five-century-old truck that an alien stole from a billionaire.”
> 

He looked ahead as the highway opened up.

> “Let’s figure out what the hell the universe is trying to tell us.”
> 

---

### II. The Road to Saskatchewan

The drive from **Calgary to Swift Current** was a full **five hours** ; and for the crew **crammed into Haoyu’s rental**, it felt more like *fifteen*.

Legs tangled. Elbows jousted. One of the kids dropped a juice box somewhere under the seat, and no one could reach it. Dmitry and Pragnya tried to coordinate logistics on their laptops, typing sideways with one hand while shielding screens from glare. Haoyu’s wife shifted constantly in the middle row, and the youngest burst into tears twice before falling asleep in a lopsided sprawl.

> “Next time,” Steven muttered, pulling his jean jacket up over his face, “I’m renting a damn bus.”
> 

Haoyu gripped the steering wheel like it was the only thing anchoring him to sanity, eyes fixed on the endless stretch of two-lane highway.

---

Meanwhile, in the Ford F1, it was paradise.

The sun cut wide golden beams across the horizon, the engine rumbled low like a sleeping dragon, and the prairie rolled out in all directions like a breathing canvas. Dallas’ ragged cowboy boots down to the floor of the gas pedal. Yuyan Chan had his feet in dressy loafers on the dash, aviators reflecting the grainfields, and a giddy grin that refused to fade.

> “I get it now,” Yuyan said, wind teasing at his hair through the cracked window. “I get the cowboy thing.”
> 

Dallas just chuckled.

> “Told ya. Ain’t nothin’ between here and the stars but air and story.”
> 
> 
> He tapped the dash lovingly.
> 
> “She’s been waitin’ five hundred years to do this drive.”
> 

They didn’t talk much after that.

Didn’t need to.

The road sang beneath the tires, the sky stayed wide and wordless, and the old truck just kept on going ; like it knew the way.

The long prairie road narrowed into a dirt drive, flanked on either side by whispering grasslands and broken fence lines. As they crested the last rise, the house and barn came into view ; and Haoyu instinctively hit the brakes for just a second, letting the moment settle over them all.

The ranch house stood proud and tall against the pale blue sky, wrapped in classic cedar plank siding. But where age should have left cracks and faded corners, there was none of it. Instead, the entire home looked… *preserved.* No, restored ; but *better*. The wood retained its earthy, time-worn charm, but gleamed as if freshly sanded and sealed every morning by invisible hands. The white-trimmed windows glinted in the sunlight. Brass door handles bore alien-clean precision, engraved in subtle motifs that seemed to shimmer only when you weren't looking directly at them.

It felt like a century-old prairie home, but... upgraded by someone who respected the past.

> “Holy hell,” Pragnya muttered in the back seat. “Did you say he lived alone? In this?”
> 

> “This place looks like if a luxury resort designer and a blacksmith got drunk together in the woods,” Steven added, genuinely impressed.
> 

The barn across the yard was a similar paradox. Still clad in old red paneling, but reinforced with shimmering metallic ribbing along the beams, and decorative hinges of gold, silver, and bronze. The roof held a solar array so discreet it looked like frost from afar.

As the caravan parked, car doors popped open in rapid succession. Stretching, groaning, gear clanking. The rental car had transformed into a pressurized can of humans and computing equipment over the five-hour trip ; an olfactory mix of coffee, takeout wrappers, and kid snacks. As Haoyu opened the trunk, a backpack fell out on his foot. He didn’t even flinch.

But all discomfort disappeared when his kids jumped out and ran straight into him.

> “DADDY!!”
> 

His daughter practically climbed him like a tree, her small arms locking around his neck, while his son gripped his leg with fierce, wordless joy ; still clutching his stuffed dinosaur like it might vanish if he let go.

Haoyu dropped to one knee, arms wrapping around them both.

> “I’m here. I’m okay. I’m right here.”
> 

His voice caught ; cracking with all the pressure he hadn’t let out in months. The weight of failed missions, media trials, planetary silence... all gone, crushed beneath two pairs of tiny arms.

His wife stepped forward, crossing her arms ; but not in anger. Her face was taut, exhausted, but she couldn’t hide the wet shimmer in her eyes.

> “I thought you’d lost your mind.”
> 

> “I wasn’t sure I hadn’t, and now you can understand - this place is off the map, the government and law enforcement will never find us here! We’re safe.” Haoyu replied confidently, standing up slowly. “But remember when I told you about that first dream? The one with all the aliens dancing out in the field here? Cowboy boots and hats, line dancing under the stars?”
> 

She blinked. Slowly.

Her gaze swept over the house. The porch. The field.

Then back to the barn.

Then to Dallas ; who nodded politely, cowboy hat tipped, clearly real.

> “Holy shit,” she whispered. “You weren’t crazy…”
> 

> “No,” Haoyu said quietly. “Or if I was ; at least now we’re all crazy together.”
> 

She leaned in and kissed his cheek. No theatrics. Just *real*.

Inside the house, it was clear: they had *more than enough space*.

the house was warm and alive. The wooden floors didn’t creak. The scent of cedar and iron mingled faintly in the air. Copper light fixtures glowed gently with no visible wires. Every door fit perfectly in its frame.

Haoyu’s wife and kids claimed the spacious living room ; their makeshift beds laid out around the central hearth. Pillows became forts. The kids' laughter echoed off the high beams as they found old board games in a carved drawer beneath the TV.

For once, Haoyu wasn’t checking the news. Or his court alerts. Or the trajectory data from the long-dead Nhexus feed.

He was just... *home*. If only for a moment.

> “Still pissed at you,” his wife said softly, laying a blanket on the floor.
> 
> 
> “I know.” said Haoyu
> 
> “But... you’re here. We’re here… and the kids are so happy.”
> 
> “Yeah. They’ve been playing and laughing like they’ve never had before.” responded Haoyu
> 
> “And it’s nice, that you aren’t working… I know it’s not ideal, but I think this will be the most we will see each other in a very long time.” Said the wife in a loving manner, cuddling up closer to Haoyu, exhilarating loving smiles on both of their faces
> 

Let’s give them some privacy; in the meantime;

Pragnya claimed the room upstairs across from Dallas’. She opened her portable console like it was a suitcase of sacred relics and began configuring diagnostics against the freshly lacquered windowsill.

> “Not bad for a haunted house,” she muttered, adjusting her lenses.
> 

Yuyan Chan and Dmitry quietly set up two bedrolls in the next room over ; Yuyan’s projection star-map blinking lazily on the ceiling as Dmitry removed a weatherproof antenna core and placed it in the window frame.

> “Room’s got strange harmonics,” Yuyan noted. “Good for telemetry.”
> 

> “Good for silence,” Dmitry replied, already halfway into a nap.
> 

---

And then ; the barn.

Steven Young had already claimed it like a wild raccoon finding a dumpster behind a fine dining restaurant.

He stood in the threshold, cowboy hat in hand, eyes glimmering like a child seeing a spaceship for the first time.

> “Now this... this is a damn holy temple of backcountry quantum science.”
> 

He stomped across the reinforced floor panels, echoing dramatically.

> “We’re settin’ up the lab here, command station there, and my bedroom? Right up in that hayloft. Give me a power strip, hot dog and a beer ; I’m golden.”
> 

Dallas appeared in the doorway, flicking a dishrag over his shoulder.

> “Just don’t rewire the place till we get the cattle fed.”
> 

> “Cattle?” Steven blinked. “Wait, are there actual cows here?”
> 

> “Two. They’re real judgy. Don’t take it personal.” Dallas remarked, walking away… then stopped before leaving the bar “Oh, and don’t mind the six legged donkey”
Steven stood in his boots like a deer in headlights, scratching his head, whispering to himself “a six legged… Huh?!”
> 

---

By late afternoon, Dallas had food sizzling on the stovetop ; sourdough on the griddle, bacon crisping beside it, and a chili stew simmering with vegetables he picked from the root cellar earlier that week.

The house buzzed with quiet science activity ; data being unpacked, spectrum readers warming up, and the guitar ; in its case, wrapped in tarp in the barn ; waiting.

Waiting to be understood.

And under the vast prairie sky, the *team was finally together*.

Ready.

The last orange threads of dusk had long vanished when the ranch finally stilled.

The barn, once creaking with life and voices, had fallen into a hushed electronic hum ; portable stations blinking soft red and green in the dark like eyes waiting to wake. Upstairs in the house, the warmth of life had settled thickly into its old-but-reborn walls, courtesy of alien renovations that preserved every creak and groove while somehow making it... pristine.

Out there, just past the barn doors, Steven Young had fallen asleep on a haybale like it was a 5-star mattress, hat over his eyes, flip-flops kicked off, and a half-empty mason jar barely hanging in the grasp of his loosely relaxed hand

He snored like a mountain lion with allergies.

Pragnya had laid claim to the room nearest Dallas’, and the woman wasted no time ; bags dumped, laptop charging, and boots off in record speed. She said she needed quiet to “align the neural overlays” from her latest string-mapped system threads. Dallas didn’t ask.

Across the hall, Dmitry and Yuyan unrolled their bedrolls like old comrades on a campaign. Yuyan, cheerful and wiry, was already debating atmospheric conversion theory through a mouthful of granola. Dmitry, quiet, focused, affixed a small dish-like sensor to the outer window, a tuned telemetry snare, designed to pick up spectral anomalies, geopathic EM variance, and most importantly... Oc’Xari interference.

Downstairs, the kids were already zonked ; curled on blankets like kittens beside a low-burning pellet stove. One clutched a dinosaur, the other still had socks on backward. Haoyu’s wife, after a long shower and a longer sigh, finally laid beside Haoyu on the twin mattresses pushed together.

Together. Finally.

She traced the edge of his face with her fingertips ; not needing to say a word at first.

Haoyu exhaled, eyes soft.

> “You remember when I told you about that first dream? The one with the Oc’Xari dancing in cowboy hats? You and me and the kids out in the field with ‘em?”
> 

She gave a little scoff, smirking through disbelief.

> “Yeah. I figured you were either hallucinating or finally having a full-blown nervous breakdown.”
> 

He laughed lightly.

> “I thought so too. God, I almost hoped I was.”
> 

She pulled closer, resting her forehead against his.

> “But you weren’t.”
> 

A breath passed between them.

> “You really weren’t.”
> 

They kissed ; gently, lovingly.

Then silence.

> “You know,” Haoyu whispered, “I think this was the best mistake I’ve ever made. Getting fired. Running away. Skipping court…”
> 

> “Facing jail time,” she added, a little dry.
> 

> “Yeah,” he smiled. “All of it. Because now I’m finally here. With you. With them. No feeds, no meetings, no Mars briefings, no command post… Just here.”
> 

She nodded, voice barely audible.

> “We missed you, you know.”
> 

> “I missed me too.”
> 

The house around them creaked in a warm, knowing way.

And the children, tangled in their nest of blankets, breathed deeply ; safe, warm, loved.

### III. The Watchers in the Night

At exactly 2:11 AM, Dmitry Alexeyev’s tablet pinged once ; a low, pulsing tone, like a sonar returning from too deep a depth.

His eyelids snapped open instantly.

He didn’t reach for the device like a man just waking ; he grabbed it like a trained soldier hearing the snap of enemy movement.

The pattern on-screen wasn't just familiar ; it was burned into him. He had spent decades working on Project Echofall, from the earliest concept phases of the rover’s hibernation logic to the live telemetry feeds from Nhexus. He was there during the signal breach that caused the public panic. He personally confirmed the first EM anomaly that triggered the planetary advisory. He was in the bunker when the rover sent back its final cursed image.

He knew the Oc’Xari signature by heart.

The signal pulsed again.

Localized. *Inside* the house.

Dmitry rose without a word. No shoes. Just the soft padding of a man used to moving through critical zones without alerting sensors or children.

First, Dallas’ room.

He creaked open the door ; just enough to see…

In the old farmhouse dark, it loomed. A shadow, barely distinguishable from night itself. Humanoid but wrong. Leaned over Dallas’ head like a mourner over a grave.

Its hand was inside Dallas’ skull. Not penetrating ; phasing, like a frequency breach, gently touching something beneath the conscious.

Dmitry froze - nerves shuttering through his body… but collecting himself

The entity looked up. Two faint lights where eyes should be. And then ; it raised its other hand, a finger to its lipless mouth.

Shhh.

Dmitry backed away. No argument. No protest. No scream.

Just reverence.

Another ping on his tablet ; second signal.

Downstairs.

He crept down. Past creaking floorboards, past portraits of families long gone, into the low firelight of the living room.

Another entity. Taller. More diffuse.

Standing over Haoyu and his wife, both deeply asleep ; its hand gently resting against Haoyu’s forehead like it was sifting through starlight.

Dmitry didn’t interfere. He sat across the room on a chair at the old farmhouse kitchen table ; lit only by the screen in his lap and the faintest shimmer from the being across the living room.

Dmitry and the Oc’Xari stared at each other for a long time.

No words.

---

[Chapter 22 - Ferron](Chapter%2022%20-%20Ferron%201ebfda674d69804a91e5eb96b87b609d.md)