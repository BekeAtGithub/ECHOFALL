# Chapter 32 - Mississippi Supermax

**Intake Ward. Sublevel 3.**

They hauled him inside like dead cargo.

His body was limp, but twitching. His eyes ; too wide, too dark. The muzzle pressed red lines into his cheeks. The straightjacket creaked every time he breathed, barely.

He was plopped down hard onto a medical cot, the kind that hummed as it scanned.

**Vitals**:

**Heart rate**: fast and irregular.

**Blood pressure**: erratic.

**Muscle mass**: atrophied beyond predictive models.

**Cognitive function**: “*unreadable*.”

Then came the psych eval.

Room 4B. Padded, sterile, humming with fluorescence.

Still in his bindings, still muzzled, Haoyu was wheeled into place like a tiger in a cage ;not a man.

Across from him sat Dr. Jennifer Lynn, forensic psychologist, 35 years in the system.

She had profiled serial killers. Torture lords. War criminals.

She clicked on her recorder.

> “Subject: Haoyu Zhang. Age, 64. Prisoner ID: Omega-Xi-Seven. Initial psychological triage.”
> 

She leaned forward. Calm. Steady.

> “Commander Zhang. Do you know where you are?”
> 

Haoyu’s head lolled sideways. His lips twitched.

> “Pig…”
> 

> “The pig is here.”
> 

Dr. Lynn frowned, but continued.

> “You’ve been in solitary for ten years. Can you tell me who the pig is?”
> 

His eyes opened wider. Pupils dilated like a corpse.

> “He lives in the pipes.”
> 

> “He tickles my butthole.”
> 

> “He taunts me while I shit.”
> 

A pause.

Then he started laughing; soft at first, then high-pitched, strained, giddy.

It didn’t last long.

He snapped back to silence so fast, the air seemed to freeze around him.

Lynn scribbled something.

> “You were a scientist, Commander. A decorated officer. A family man. Do you remember your family?”
> 

Haoyu didn’t answer.

Then, with sudden clarity, he whispered:

> “I forgot them.”
> 

A long breath.

> “He made me forget…”
> 

> “My daughter… my son…”
> 

> “They were… names in a dream I don’t… I don’t know if I made them up… The pig was telling me every day; it was just my imagination... I can’t… quite put a finger on it… was my wife… real? my kids…”
> 

Haoyu Zhang zoned out blankly in deep thought.

Lynn stared, frozen.

In 35 years, she had assessed nearly five hundred broken minds.

> “He’s in a severe state of amnesia,” she murmured into her recorder.
> 

She leaned closer, despite every instinct telling her not to.

> “Haoyu, is the Pig in the room with us? Right now?”
> 

He shook his head. Slowly. Without blinking.

> “Not… right here, but he’s close. He’s very close.”
> 

> “He’s sleeping in the vents, I can hear him snoring... we have to be quiet” he whispered
> 

> “Sometimes, when I’m pissing, he climbs out of the hole… and tortures my cock and balls.”
> 

Lynn had to look away. Her hands were shaking.

Haoyu kept speaking.

> “You think I’m here ‘cause I ran from court?”
> 

> “Because I took my family on a vacation to hell?”
> 

He coughed ; a sick, raspy laugh.

> “You’re wrong.”
> 

> “I opened the door.”
> 

> “It was me. The Echofall probe… it wasn’t just science. It was an invitation.”
> 

He slumped.

> “We opened a gate… I don’t know to where, but he came through…”
> 

> “And now… he’s using us like toys.”
> 

Silence

> “Haoyu Zhang is no longer fit for public or private containment.”
> 

> “His execution should be scheduled promptly.”
> 

Two guards stepped into the room ; silent, armored, emotionless, they came to take him away…

But before they could touch him, Dr. Lynn raised a hand.

> “One more moment.”
> 

The guards paused.

She glanced at her assistant ; a nurse with trembling hands ; and then looked back at Haoyu.

> “Commander Zhang…” she asked softly. “Do you remember the planet Nhexus?”
> 

His eyes twitched. Lips parted. Something stirred behind the madness.

> “Do you remember the invasion alerts you raised… the ones the world dismissed?”
> 

> “The leaked footage… the pyramid structures on the dead world?”
> 

At first, just silence.

But then;

A tremble.

And then ; clarity.

His posture shifted, ever so slightly. The shaking slowed. His voice grew steady, grave. For a moment, it was as if - Zhang was completely normal…

> “The Echofall probe landed in the Expanse Quadrant, Region Theta-19. The terrain was scorched. Dust was red. The sky was thin… fractured. Dead but not still.”
> 

> “The rover transmitted seventeen full panoramic sweeps. But Frame 213-B… showed something else.”
> 

He looked up, directly at the doctor.

> “Entities.”
> 

> “Shadow-formed. Bipedal. When we conducted multiple scans and tests with the EON7-b rover, it was clearly confirmed in the data… these entities were not from Nhexus, instead they were ethereal beings from another planet called Oc’Xari.”
> 

> “They were there for months, standing near the base of the central pyramid. Watching the rover, until later during Easter was when we captured the first real image of it, with scans and tests 100% confirming what we saw was not a hallucination.”
> 

Lynn blinked.

He went on.

> “Then, I… I started having these strange dreams. There was this saloon, called the Chuckwagon Cafe… in Diamond Valley, Alberta… I… I’ve never even been to Canada before, I never heard of it. But that’s where I met Dallas, and that’s where the … the…”
> 

Lynn leaning forward “The what? What was there in the Saloon?”

His voice cracked. As his clarity started to fade, back into fear and hysteria

> “He… he woke up… he’s in the vents, he’s crawling, he’s coming, oh noooo, he heard me, and he’s coming, noo, no, please, please save me.”
> 

He cried and wimpered to Jennifer Lynn like child trying to hide from a bully, but unable to move, still restrained.

His gaze shifted. Past Lynn. Behind her.

His breathing grew shallow. Eyes wide open.

And he started to profusely panic.

Not just tears ; but desperate, choking sobs, his body curling in on itself like a beaten dog.

> “Please…” he whispered. “No. Not again. Please…”
> 

Dr. Lynn felt some sort of presence behind her… over her left shoulder, where Haoyu was fixated at… the hair on her arms stood up, she slowly turned her head.

Just a glance.

Just enough to look behind her.

Nothing there.

Just a padded wall.

She sighed. A flicker of frustration crossing her brow ; the embarrassment of being tricked by a crazed lunatic.

Haoyu started yelping, his body jutting every 2-4 seconds, screaming he’s sorry, as if someone was beating him.

She gave a silent signal to the guards.

And as they dragged him from the room ; Haoyu screaming, weeping, begging for someone, anyone, to make it stop ; the doctor pressed a final note into her recorder:

> “Subject exhibits signs of advanced trauma psychosis.”
> 

> “Critical PTSD inflicted by extended isolation, guilt, and prolonged exposure to leaked reconnaissance from the planet Nhexus.”
> 

> “Symptoms include extreme hysteria, memory degradation, persistent hallucinations of anthropomorphic entities, and delusional thought loops.”
> 

> “Recommendation: sentence continuation. Execution order confirmed.”
> 

She signed the report. Time-stamped. Biometrically sealed.

Whispered to herself in pity “Put him out of his misery, let him rest.”

The system processed it within the hour.

By midnight, the execution was approved.

The date was set: three days from now.

No appeals.

No hearings.

No hope.

Just three more days…

Three more nights…

Of nonstop torture inside the Mississippi Supermax.

Because the Pig ; the thing that had followed Haoyu through the stars, through his dreams, through the fold of his own mind ; lived in that cell now.

It breathed in the corners.

It scratched at the walls.

It whispered behind the drain.

It laughed when the lights flickered.

And as the countdown began, Haoyu Zhang ; once a commander, once a father, once a hero ; was reduced to nothing but a crazed mongrel.

[Chapter 33 - Decay](Chapter%2033%20-%20Decay%201eefda674d69807498f9cbde2ff677b8.md)