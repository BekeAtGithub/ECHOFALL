# Chapter 41 - Dmitry’s Choice

This story has 3 alternative endings.

You as the reader can now pick what option Dmitry chooses.

**Option 1. [Chapter 42 - Option 1](Chapter%2042%20-%20Option%201%201ecfda674d698036a0b0edfb304478c8.md)** 

> “Do nothing. Call the Pig’s bluff. All of Dmitry’s friends and family die and are haunted forever, or nothing happens.”
> 

Option 2. [Chapter 43 - Option 2](Chapter%2043%20-%20Option%202%201ecfda674d6980f4a1c0d319c1fe6785.md) 

> “Bring the Oc’Xari artifact to the Pig. Rewinds time, fixes all the problems. Everyone forgets everything. The horror stops, but at the cost of Oc’Xari genocide.”
> 

Option 3. [Chapter 44 - Option 3](Chapter%2044%20-%20Option%203%201ecfda674d698064aeb3cea2702694e7.md) 

> “Put the Avaris artifact into the Oc’Xari artifact. Save the Oc’Xari, unite Humanity with the Avaris and Oc’xari. Prepare for the Pigs retaliation."
>