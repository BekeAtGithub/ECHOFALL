# Chapter 42 - Option 1

### **I. Another Round in Saskatchewan**

**Swift Current, Saskatchewan - 11:47 PM**

After a nonstop one-shot drive across the stretching Canadian prairie, mostly taking the smaller lesser known highways to try and evade police looking for the stolen vehicle along the Trans-Canada Highway. Dmitry and Steven finally rolled into the outskirts of Swift Current under a dim, frost-bitten sky. The journey had been long ; mostly silent ; with only occasional bursts of conversation to break the tension. Neither man had much left to say. Their thoughts ran in circles, spiraling around the same three possibilities: deliver the artifact, defy the Pig, or gamble on something even riskier.

They’d stopped twice for gas, once for snacks ; each time brief, silent, mechanical. The roads had been clear, eerie in their emptiness, the highways ghostlike beneath the dim shimmer of the slowly rising moon.

By the time they reached the heart of the town, it was nearing midnight. The place looked dead. Frozen. The sidewalks were glazed in layers of old ice, the roads half-lit by flickering yellow lamps. Everything had that abandoned feel ; as if even time had forgotten Swift Current.

# **The Variation**

“You know- I’ve been thinking.” Dmitry finally spoke after a long ride of thought.

“The Pig said, he can’t interact with physical objects that were made by things he didn’t create. The Pig can’t manipulate things physically, he doesn’t really have that much control. I don’t think he can turn back time either. If he had all this power, he could go get the guitar himself.”

Steven thought, and replied “Yeah, I thought about this several times throughout our trek… he also was getting impatient at the meeting table. Like if he wanted to get this all done asap, he would have found another way to do it… Dallas’s barn is like a fucking spawn point for demons.”

“-And the guitar is a link or a tuning mechanism for said spawn point”- added Dmitry.

As they pulled up to the police station, they looked inside and saw a dim light, just a lone police officer watching a tv show… looked like he was sleeping.

“What the police station is also tainted by harboring the artifact?” Steven wondered out loud.

Dmitry pulled off to a side street, as they watched the police station from afar. Then he added- “I don’t really trust the pig, but I don’t trust the Oc’Xari either. And the Avaris seemed like it just randomly got thrown into all of this as a last ditch effort, they are probably just as clueless as us.”

“I’m gonna give you another option Dmitry.” Steven taunted goofily trying to imitate the voice of the pig. They both laughed a bit over it… then Steven continued “If the Pig is serious, I’m gonna die, but I somehow think he’s full of shit. My option to you is - we go to the nearest gas station, fill up a few jerry cans - we come back to the police station, burn it down, and we go to the barn and we burn it down. Burn all the links that were opened to other worlds.”

“The police officer will extinguish the fire…” argued Dmitry.

Steven pulled his glock out checking the ammo - Dmity annoyingly added “ **tsssk** we are not going to kill the cop.”

“Dmitry I’m serious - this might even be a better idea - we kill the cop, we enter and burn the guitar, we burn the other artifact they gave you - then we go to Dallas’ Ranch and we burn that down too, and we escape to Northern Canada through the ice storms.”

Silence passed, just the sound of the soft, luxury engine humming of the SUV, and wind howling outside.

Without a word, Dmitry started driving down the street, until they reached a gas station. 

They picked out a few jerry cans, filled them up with gasoline and placed them in the trunk of the SUV beside a nice big wrench… Dmitry grabbed the wrench and brought it with him to the front seat.
Then headed back to the police station.

**The Plan**

He pulled out a folded napkin and drew a crude layout of the station, based on their drive-by recon.

> “There’s a back door here,” he pointed. “Likely leads to a small hallway. Locker room, bathroom, maybe holding cell. If the artifact’s locked up anywhere, it’s either in evidence… or the armory.”
> 

> “Or,” Steven added, “sittin’ on some dumbass desk ‘cause the guy inside thinks it’s just some busted alien banjo.”
> 

Dmitry continued.

> “I’ll go around back. Quietly. You go through the front. Start knocking, draw his attention ; talk to him, pretend you need help or something.”
> 

> “Then what?”
> 

> “Then I’ll sneak in, and I will beat him over the head with this wrench. We zip-tie him, gag him. Non-lethal if possible.”
> 

Steven raised an eyebrow.

> “Like how I non-lethally killed the drug dealer back in Seattle?”
> 

Dmitry shrugged.

> “Yeah like that - if it doesn’t work, we can shoot him - but that is only worst case scenario.”
> 

> “Got it, I’ll shoot down the snow bear if the plan goes south.”
> 

> “Once he’s down, maybe thirty minutes before anyone even thinks to check in. We find the evidence locker. Grab the guitar artifact. Then we get out. Fast, and we can burn it in a field.”
> 

Steven took a long breath. Then double checked under his jacket ensuring the Glock and magazines were secured, and nodded.

> “Alright. Let’s rob ourselves a police station.”
> 

### **II. The Assault**

**The Break-In was underway**

They headed to their positions. 

[Chapter 44 - Option 3](Chapter%2044%20-%20Option%203%201ecfda674d698064aeb3cea2702694e7.md)